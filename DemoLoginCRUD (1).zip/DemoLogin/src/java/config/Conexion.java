/**
 *
 * @author Rodrigo Ortiz
 */
package config;
//Imports
import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {
    //Definir los atributos de clase
    private Connection conn;
    String jdbc;
    String ruta;
    String userdb;
    String passdb;
    String dbname;
    
    public Connection Conexion()
    {
        this.conn = null;
        this.dbname = "mystore";
        this.userdb = "root";
        this.passdb = "";
        this.jdbc = "com.mysql.jdbc.Driver";
        this.ruta = "jdbc:mysql://localhost:3306/"+dbname;
        
        try {
            Class.forName(this.jdbc);
            this.conn = DriverManager.getConnection(this.ruta, this.userdb, this.passdb);
        } catch (Exception e) {
        }
        
        return conn;
    }
}
